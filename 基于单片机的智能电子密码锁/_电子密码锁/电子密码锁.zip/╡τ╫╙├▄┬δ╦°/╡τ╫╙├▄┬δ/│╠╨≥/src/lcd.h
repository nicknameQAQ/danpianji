#ifndef __LCD_H_
#define __LCD_H_

#include<reg51.h>

//---�ض���ؼ���---//
#ifndef uchar
#define uchar unsigned char
#endif

#ifndef uint 
#define uint unsigned int
#endif

typedef unsigned char uint8;
typedef unsigned int uint16;
sbit rs=P2^5;	 // ��������ѡ��
sbit rw=P2^4;	 //��дѡ��
sbit e=P2^3;	  //ʹ��

void Lcd1602_Delay1ms(uint16 i);

void LcdWriteCom(uchar com);
	
void LcdWriteData(uchar dat);
	
void LcdInit();	

void LCDWrite_String(uchar x, uchar y,uchar z, uchar *s);

void LCD_set_xy(uchar x, uchar y, uchar z);					  

#endif
