#include "DSP281x_Device.h"   
 
 int max(int aa[],int num)
 {int maximum=0;
 int k;
 for (k=0;k<num;k++)
    { if(maximum<aa[k])
     maximum=aa[k]; 
     }
     return maximum;
 }
 
 
 void clear(int aa[], int num)
  {int k;
  for (k=0;k<num;k++)
      aa[k]=0;
  } 

 
float mean(float bb[],int num)
 {int  k;
  float avg=0.0;
  for (k=0;k<num;k++)
  
       {
   avg+=bb[k];
       }
  avg/=num;
 return avg;
} 
float mean2(float bb[],int num,int * sin,float *avg1)
{
int k,j,i;
float temp;
float aa[200];
float avg=0.0;
*sin=0;
for(k=0;k<num;k++)
{for (j=k+1;j<num;j++)
 if (bb[k]>bb[j]){temp=bb[k];bb[k]=bb[j];bb[j]=temp;}
}
for (k=0;k<num;k++){aa[k]=bb[k];}
j=num*0.3333;i=num*0.66667;
if(i<1)i=1;
for (k=0;k<num;k++)
       {
   avg+=aa[k];
       }
  avg/=(num);
  temp=avg;
if((aa[num-1]-aa[0])>avg*0.0001)*sin=1;
if(*sin==1)
 {
  //if((*avg1-avg)<0.001&&(*avg1-avg)>-0.001)
   //  avg=(*avg1+avg)*0.5;
    *avg1=temp;
}


  if(avg<50)EvbRegs.T3CMPR =65530;
  else EvbRegs.T3CMPR =65000;
  /*if((aa[num-1]-aa[0])>avg*0.0001)
  {
  if(avg<35.99)avg*=1.0003;
   else if (avg<38.99)avg*=1.00025;
   else if(avg<39.99)avg*=1.0002;
   else avg*=1.0001; 
  }*/
 return avg;
}

/*float mean2(float bb[],int num)
{int k,j;
float temp;
float aa[20];
float avg=0.0;
for(k=0;k<num;k++)
{for (j=k+1;j<num;j++)
 if (bb[k]>bb[j]){temp=bb[k];bb[k]=bb[j];bb[j]=temp;}
}
for (k=0;k<num;k++){aa[k]=bb[k];}
for (k=5;k<num-5;k++)
       {
   avg+=bb[k];
       }
  avg/=(num-10);
 return avg;

}*/
int boxing(int aa[], int num)
{int xdgs=0;
 int xdgstemp;
 int j, k;
   for (j=0;j<num;j++)
 {
        xdgstemp=1;
        for (k=0;k<num;k++)
         {
          
          if(-20<(aa[j]-aa[k])&&(aa[j]-aa[k])<20)
          xdgstemp++;
         }       
  if(xdgs<xdgstemp)       xdgs=xdgstemp;
         
 }
 if(xdgs>num/3)
  return 0;
 else 
   return 1;
 
 }

