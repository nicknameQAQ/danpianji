//###########################################################################
//
// FILE:	DSP281x_Ev.c
//
// TITLE:	DSP281x Event Manager Initialization & Support Functions.
//
//###########################################################################
//
//  Ver | dd mmm yyyy | Who  | Description of changes
// =====|=============|======|===============================================
//  1.00| 11 Sep 2003 | L.H. | No change since previous version (v.58 Alpha)
//###########################################################################

#include "DSP281x_Device.h"     // DSP281x Headerfile Include File
#include "DSP281x_Examples.h"   // DSP281x Examples Include File

//---------------------------------------------------------------------------
// InitEv: 
//---------------------------------------------------------------------------
// This function initializes to a known state.
void InitEv(void)
{

    EvaRegs.GPTCONA.all = 0;
	EvbRegs.GPTCONB.all = 0;
    EvaRegs.EXTCONA.bit.INDCOE=1;//
    EvaRegs.GPTCONA.bit.T1CMPOE = 1;//ʹ��T1�Ƚ����,��������ʹ�ܽ�ֹ
   
    EvbRegs.EXTCONB.bit.INDCOE=0;
    EvbRegs.GPTCONB.bit.TCMPOE = 1;//ʹ��T3�Ƚ����
   	//��ͨ�ö�ʱ��1�ıȽ�������óɵ͵�ƽ��Ч
	EvaRegs.GPTCONA.bit.T1PIN = 1;
    EvaRegs.T1CON.all = 0x101a;// ����ʱ��1���ó�����������ģʽ�ⲿʱ�ӣ�ʹ��T1�Ƚ�   
    EvaRegs.T1PR=0xffff;
    EvaRegs.T1CMPR=1;  
       
    EvaRegs.T2PR = 0xffff;                                      
   	EvaRegs.T2CON.all = 0x1288;  // ����ʱ��2���ó�����������ģʽ//4��Ƶ�� �� ��ʱ�� 
    EvbRegs.T4PR=0xffff;
    EvbRegs.T4CON.all=0x1000; //T4 �ڲ�ʱ�� 
    
    EvaRegs.CAPCONA.all= 0x04E4;  //CAP3ʱ��ΪT1,����ϱ���, CAP1ʱ��ΪT2 ,�����������
                 
                   
    EvbRegs.CAPCONB.all=0x0064; //CAP4������ cap5�½���               
       
    EvbRegs.T3PR = 0xffff;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
    EvbRegs.T3CMPR =60000;//T3CMPR����Ϊ10000 Ԥ��ʱ��  
   	EvaRegs.GPTCONA.bit.T1CTRIPE = 1;
}
